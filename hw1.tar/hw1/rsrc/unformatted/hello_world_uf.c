#include <stdio.h>

// -l option
// Total number of lines: 6

int main(int argc, char *argv[]){printf("Hello, world!\n");return 0;}