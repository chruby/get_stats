#include <stdio.h>

// -w option
// Max line width is 41

int main(int argc, char* argv[]) {
  printf("a\n");
  printf("ab\n");
  printf("abc\n");
  printf("abcd\n");
  printf("abcde\n");
  printf("abcdef\n");
  printf("abcdefg\n");
  printf("abcdefgh\n");
  printf("abcdefghi\n");
  printf("abcdefghij\n");
  printf("abcdefghijk\n");
  printf("abcdefghijkl\n");
  printf("abcdefghijklm\n");
  printf("abcdefghijklmn\n");
  printf("abcdefghijklmno\n");
  printf("abcdefghijklmnop\n");
  printf("abcdefghijklmnopq\n");
  printf("abcdefghijklmnopqr\n");
  printf("abcdefghijklmnopqrs\n");
  printf("abcdefghijklmnopqrst\n");
  printf("abcdefghijklmnopqrstu\n");
  printf("abcdefghijklmnopqrstuv\n");
  printf("abcdefghijklmnopqrstuvw\n");
  printf("abcdefghijklmnopqrstuvwx\n");
  printf("abcdefghijklmnopqrstuvwxy\n");
  printf("abcdefghijklmnopqrstuvwxyz\n");
  return 0;
}